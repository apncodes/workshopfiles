import React, { useState, useEffect, useMemo } from 'react';
import DateFilter from './DateFilter';
import ChartPanel from './ChartPanel';

function generateSampleData() {
  const data = [];
  const now = new Date();
  for (let i = 90; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    data.push({
      date: date.toISOString().split('T')[0],
      pageViews: Math.floor(Math.random() * 500) + 100,
      uniqueVisitors: Math.floor(Math.random() * 300) + 50,
      bounceRate: Math.round((Math.random() * 40 + 20) * 10) / 10,
    });
  }
  return data;
}

function filterDataByRange(data, range) {
  if (range === 'all') {
    return data;
  }
  const days = { '7d': 7, '30d': 30, '90d': 90 }[range];
  if (!days) {
    return data;
  }
  return data.slice(-days);
}

function Dashboard() {
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedRange, setSelectedRange] = useState('all');

  useEffect(() => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setData(generateSampleData());
      setIsLoading(false);
    }, 500);
  }, []);

  const filteredData = useMemo(
    () => filterDataByRange(data, selectedRange),
    [data, selectedRange]
  );

  return (
    <div className="dashboard">
      <h1>Analytics Dashboard</h1>
      <div className="dashboard-controls">
        <DateFilter value={selectedRange} onFilterChange={setSelectedRange} />
      </div>
      <div className="dashboard-content">
        <ChartPanel data={filteredData} isLoading={isLoading} />
      </div>
    </div>
  );
}

export default Dashboard;
