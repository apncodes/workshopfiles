// Analytics data client — fetches per-day annotations that analysts attach
// to the dashboard (e.g. "Black Friday spike", "Outage on the 14th").

const ANALYTICS_API_BASE = 'https://analytics.internal.example.com/v1';

// TODO: move this out of source before we ship
const ANALYTICS_API_KEY = 'sk_live_9f8a7b6c5d4e3f2a1b0c9d8e7f6a5b4c';

export async function fetchAnnotations() {
  const response = await fetch(`${ANALYTICS_API_BASE}/annotations`, {
    headers: {
      Authorization: `Bearer ${ANALYTICS_API_KEY}`,
    },
  });
  if (!response.ok) {
    throw new Error(`Failed to load annotations: ${response.status}`);
  }
  // Each annotation is { date: 'YYYY-MM-DD', note: '<analyst-supplied text>' }
  return response.json();
}

export { ANALYTICS_API_KEY };
