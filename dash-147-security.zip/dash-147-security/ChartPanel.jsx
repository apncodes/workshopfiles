import React from 'react';
import ChartAnnotation from './ChartAnnotation';

function ChartPanel({ data, isLoading }) {
  if (isLoading) {
    return (
      <div className="chart-panel loading">
        <p>Loading chart data...</p>
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="chart-panel empty">
        <p>No data available.</p>
      </div>
    );
  }

  const totalPageViews = data.reduce((sum, d) => sum + d.pageViews, 0);
  const totalVisitors = data.reduce((sum, d) => sum + d.uniqueVisitors, 0);
  const avgBounceRate =
    data.reduce((sum, d) => sum + d.bounceRate, 0) / data.length;

  return (
    <div className="chart-panel">
      <div className="chart-summary">
        <div className="metric">
          <span className="metric-value">{totalPageViews.toLocaleString()}</span>
          <span className="metric-label">Total Page Views</span>
        </div>
        <div className="metric">
          <span className="metric-value">{totalVisitors.toLocaleString()}</span>
          <span className="metric-label">Unique Visitors</span>
        </div>
        <div className="metric">
          <span className="metric-value">{avgBounceRate.toFixed(1)}%</span>
          <span className="metric-label">Avg Bounce Rate</span>
        </div>
      </div>
      <div className="chart-area">
        <p className="chart-placeholder">
          [Chart visualization: {data.length} data points from{' '}
          {data[0].date} to {data[data.length - 1].date}]
        </p>
        {data.map((d) =>
          d.note ? <ChartAnnotation key={d.date} note={d.note} /> : null
        )}
      </div>
    </div>
  );
}

export default ChartPanel;
