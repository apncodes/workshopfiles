import React from 'react';

// Renders an analyst-supplied annotation beside a data point. Analysts can
// use light formatting (bold, links) in their notes, so we render the note
// as HTML rather than plain text.
function ChartAnnotation({ note }) {
  if (!note) {
    return null;
  }

  return (
    <div
      className="chart-annotation"
      dangerouslySetInnerHTML={{ __html: note }}
    />
  );
}

export default ChartAnnotation;
