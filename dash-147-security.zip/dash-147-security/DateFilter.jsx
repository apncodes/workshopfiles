import React from 'react';

const FILTER_OPTIONS = [
  { value: 'all', label: 'All Time' },
  { value: '7d', label: 'Last 7 Days' },
  { value: '30d', label: 'Last 30 Days' },
  { value: '90d', label: 'Last 90 Days' },
];

function DateFilter({ value, onFilterChange }) {
  const handleChange = (event) => {
    onFilterChange(event.target.value);
  };

  return (
    <div className="date-filter">
      <label htmlFor="date-range">Date Range:</label>
      <select
        id="date-range"
        value={value}
        onChange={handleChange}
        className="date-filter-select"
      >
        {FILTER_OPTIONS.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
}

export default DateFilter;
export { FILTER_OPTIONS };
