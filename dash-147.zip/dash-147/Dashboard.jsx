import React, { useState, useEffect } from 'react';
import DateFilter from './DateFilter';
import ChartPanel from './ChartPanel';

function generateSampleData() {
  const data = [];
  const now = new Date();
  for (let i = 90; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    data.push({
      date: date.toISOString().split('T')[0],
      pageViews: Math.floor(Math.random() * 500) + 100,
      uniqueVisitors: Math.floor(Math.random() * 300) + 50,
      bounceRate: Math.round((Math.random() * 40 + 20) * 10) / 10,
    });
  }
  return data;
}

function Dashboard() {
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setData(generateSampleData());
      setIsLoading(false);
    }, 500);
  }, []);

  return (
    <div className="dashboard">
      <h1>Analytics Dashboard</h1>
      <div className="dashboard-controls">
        <DateFilter />
      </div>
      <div className="dashboard-content">
        <ChartPanel data={data} isLoading={isLoading} />
      </div>
    </div>
  );
}

export default Dashboard;
