# Bug Report: DASH-147

**Title:** Date filter dropdown doesn't work
**Reporter:** Sarah (PM)
**Priority:** High
**Component:** Analytics Dashboard — Date Filter

## Description

Users select "Last 7 Days" from the dashboard's date filter dropdown, but the chart still shows all-time data. The dropdown visually updates — it shows "Last 7 Days" as the selected option — but the chart data doesn't change. This has been reported by multiple customers.

## Steps to Reproduce

1. Open the Analytics Dashboard
2. Note the chart is showing all-time data (90 days)
3. Click the "Date Range" dropdown (currently shows "All Time")
4. Select "Last 7 Days"
5. Observe: the dropdown shows "Last 7 Days" but the chart still displays all 90 days of data

## Expected Behavior

After selecting "Last 7 Days," the chart should update to show only the last 7 days of data. The summary metrics (Total Page Views, Unique Visitors, Avg Bounce Rate) should also recalculate based on the filtered data.

## Actual Behavior

The dropdown visually updates to show the selected option, but the chart and summary metrics continue to display all-time data regardless of which filter option is selected.

## Environment

- Affects all browsers (Chrome, Firefox, Edge)
- Affects all users
- First reported: this week, but may have been present since the dashboard was launched

## Notes

The dropdown itself seems to work fine — it opens, shows all options, and visually reflects the selection. The problem is that the selection doesn't affect the chart in any way.
